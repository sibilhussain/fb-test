<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Verify extends CI_Controller {


	public function index()
	{
	// assign values to variables	
	   $key = $this->input->get('key');
	// load model   
       $this->load->model('verifymodel');
       $verify = new verifymodel();
       $datas['key'] = $key;
      $msg['data'] = $verify->verification($datas);
      print_r($msg);
      if ($msg['data']['code']==404) {
      	header('Location: http://sibilhussain.com/facebook-clone/index.php/Mypage/Verify?email='.$msg['data']['email']);
      }
      elseif ($msg['data']['code']==303)
      {
      header('Location: http://sibilhussain.com/facebook-clone/index.php/Mypage/Verifyfalse');
      }
	}
}
