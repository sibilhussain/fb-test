<?php
class Signupmodel extends CI_Model
{

	public function signauth($catch)
	{
     
       $this->load->database();
		$query=$this->db->select('vchr_email')
				->from('tbl_user')
				->where('vchr_email',$catch['chr_email'])
				->get();
				$location ="profile/";
				$hash = md5(uniqid(rand(), true));
			$ext = '.'.pathinfo($catch['file-name'], PATHINFO_EXTENSION);
            $filename = $hash . ' ' .$ext;
            $date = $catch['int_day'].'/'.$catch['int_month'].'/'.$catch['int_year'];
            $chr_email =  $catch['chr_email'];	
            $chr_fname= $catch['chr_fname'];
            $chr_lname = $catch['chr_lname'];
            $int_pass = $catch['int_pass'];
            $dob= $catch['int_year'].'/'.$catch['int_month'].'/'.$catch['int_day'];
            $gender = $catch['gender'];

 		// check  email exist or not
		if($query->num_rows()>= 1)
	     {
        	$msg  = array('Respones' => 'User alredy Existed!','code'=>'202');		
              
            }
            else{
         //upload profile picture
           if(copy($catch['file-tmp'], $location.$filename))
          {
              //use Mysql procedure
                 $this->db->query("CALL insertval('$chr_email','$int_pass','$chr_fname','$chr_lname','$dob','$gender','false','$filename','$hash')");
                 
                 $this->session->set_userdata('hashkey',$hash);
                 $key = $this->session->userdata('hashkey');
                 $msg  = array('Respones' =>'Successfull','code'=>'404','key'=>$key,'email'=>$chr_email);
                 }
                 else
                 {
                  $msg  = array('Respones' => 'Uploading Failed','code'=>'303');
                 }
   
         

          }
           return $msg;
		

	}
}
?>