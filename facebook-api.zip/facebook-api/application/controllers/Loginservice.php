<?php

class loginservice extends CI_Controller
{

public function login()
{
	
    
	$catch['vchr_email'] = $this->input->get_post('email');
	$catch['varchar_pass'] = $this->input->get_post('password');

	if(empty($catch['vchr_email']) or empty($catch['varchar_pass']))
	{
       $msg = array('RESPOND' =>'505','MSG'=>'INCORRECT USERNAME OR PASSWORD');
       echo json_encode($msg);
	}
	else
	{
	$this->load->model("loginmodel");
	$result=$this->loginmodel->userauth($catch);
	echo json_encode($result);
    //print_r($catch);
    }
}

}

?>