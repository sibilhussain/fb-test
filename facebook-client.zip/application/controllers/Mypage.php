<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class mypage extends CI_Controller {

	
	public function index()
	{
		$this->load->view('myview');
	}
	public function pass_wrg()
	{
		$this->load->view('pass_wrg');
	}
	public function email_wrg()
	{

		$this->load->view('email_wrg');
	}
	public function main_view()
	{
	
		$this->load->view('mainview');
	}
	public function verify()
	{
	   $email['data'] = $this->input->get('email');
	   $this->load->view('verify-true',$email);	
	}
	public function verifyfalse()
	{
	   $this->load->view('verify-false');	
	}
}
