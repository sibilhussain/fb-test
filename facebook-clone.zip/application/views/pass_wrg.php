<html>
<head>
	<?php
	$this->load->helper('url');
	?>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.min.css">
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/pass_wrg.css">
</head>

<body>
<div class="header" style="background:#3b5998;">
	<div class="row">
    <div class="col-md-offset-2 col-md-3">
<img src="http://sibilhussain.com/facebook-clone/bootstrap/image/logo.png">
    </div>
    <div class="col-md-1">
    	<a class="btn btn-success" style="margin-top:41px; margin-bottom:-50; margin-left:-70px;" href="<?php echo base_url(); ?>" role="button">SignUp</a>
    </div>
	</div>
</div>
<div class="container" style="background:#e9eaed;">
	<div class="row">
		<div class="col-md-offset-3 col-md-6 col-md-offset-3">
			<div class="box">
    <?php
      
      foreach($data as $user)
  
        ?>
               <div class="content">
                     <div class="col-md-12">
                     	<h4 style="color:#555; padding:5px;">Facebook Login</h4>
                     	<hr style="margin:-5px;">
                  <div class="details_cntr">
                  <div class="left">
                  <div class="txt_1">
                  	<label>Login as:</label>
                  </div>
                  <div class="txt_1">
                  	<label>Password:</label>
                  </div>
                  </div>
                  <div class="middle">
                  <div class="f_img" style="background:; height:80px; width:80px; border:1px solid #ddd;">
           <?php echo '<img width="80px" src="http://sibilhussain.com/facebook-clone/facebook-api/profile/'.$data['PIC'].'">'; ?>
                  </div>
                   <div class="f_name" style="width:100px; background:; height:20px;">
                    Not .....?
                  </div>
                  </div>
                  <div class="right">
                  	<table style="margin-top:20px;">
                  		<tr>
                  			<td colspan=""><?php echo $data['FIRSTNAME']; ?></td>
                  		</tr>
                  		<tr>
                  			<td colspan=""><?php echo $data['LASTNAME']; ?></td>
                  		</tr>
                  	</table>
                  </div>
                  <div class="c_area" style="float:right; width:270px;background:;height:100px;">
<div class="" style="width:270px; height:30px; padding:2px;background:;">
<input type="text" style="width:230px; ">
</div>
<div class="" style="width:270px; height:30px; padding:2px;background:;">
<input type="checkbox" name=""> keep me logged
</div>
<div class="" style="width:270px; height:30px; padding:2px;background:;">
<button class="button" style="background:#3b5998; border:0px;color:#fff; padding:3px;">Log in</button> or <a href="#">Sign Up For Facebook</a>
</div>
<div class="" style="width:270px; height:30px; padding:2px;background:;">
	<a href="">Forgotten Password</a>
	</div>
                  </div>
                  </div>
                     </div>
               </div>

			</div>
		</div>
	</div>
	</div>

<footer id="foot_bg" style="    background: #fff;
    height: 150px;"> 
<div class="col-md-offset-1 col-md-10 col-md-offset-1 hidden-sm" style=";">
    <ul class="list-inline " style="border-bottom:0px solid #ddd;">
        <li>English</li>
        <li>മലയാളം</li>
        <li>தமிழ்</li>
        <li>English</li>
        <li>ಕನ್ನಡ</li> 
        <li>हिन्दी</li>
         </li>اردو</li>
          <li>বাংলা</li> 
        <li>తెలుగు</li>
         <li>Español</li>
         <li> Português (Brasil)</li>
    </ul>

<hr style="width: 100%; color: #AFA7A7; height: 1px; background-color:#AFA7A7;">
</div>
<div class="col-md-offset-1 col-md-10 col-md-offset-1 hidden-sm" style="">
    <ul class="list-inline " style="border-bottom:0px solid #ddd;">
        <li>Sign Up</li>
        <li>login</li>
        <li>Messenger</li>
        <li>Facebook</li>
        <li>Lite</li> 
        <li>Mobile</li>
         </li>Find Friend</li>
          <li>Badges</li> 
        <li>People</li>
         <li>Page</li>
         <li> Place</li>
         <li>Games</li>
         <li>Celebrities</li>
       <li>  Groups</li> <li>About  </li> <li>Create Advert</li>  <li> Create Page</li><li> Developers </li> <li>Careers </li> <li>Privacy Cookies</li> <li>AdChoices </li><li>Terms Help</li>
    </ul>
Facebook © 2016
</footer>
</body>


</html>