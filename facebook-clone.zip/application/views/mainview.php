<html>
<head>
	<?php
	$this->load->helper('url');
	?>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.min.css">
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.min.js"></script>
<style type="text/css">
body
{
	margin: 0px;
}
nav
{
	background-color: #3b5998;
	background-image:linear-gradient(#4e69a2, #3b5998 50%);
	width: 100%;
	height: 60px;
}
.top_search
{
	margin-top: 13px;
	width: 500px;
}
.search_icon
{
	position: absolute;
	margin-left: 480px;
	margin-top:21px;
	color: #ccc;
}
.nav_right
{
	width: 200px;
	height: 50px;
	margin-top: 5px;

}
.nav_right .left
{
	width: 60px;
	height: 50px;
	float: left;
}
.nav_right .right
{
	width: 140px;
	height: 50px;
	background: ;
	float: right;
	line-height: 50px;
	font-weight: bold;
	font-size: 15px;
	padding-left: 2px;
}
.wrapper
{
	background: linear-gradient(white, #D3D8E8);
	height: 600px;
}
ul{
	list-style: none;	
}
li{
	padding: 2px 2px 2px 5px;
	color: #333;

}
.right_mrg
{
	margin-right: 5px;
}
.center_container
{
	width: 650px;
	height: 200px;
	background: #FFF;
	padding: 1px 2px 2px 2px;
	box-shadow: 1px 2px 2px #ddd;
	border: 1px solid #ddd;
}
.center_container_row
{
	width: 640px;
	margin-left: auto;
	margin-right: auto;
	height: 30px;
	background: ;
	margin-top: -5px;
	border-bottom: 1px solid #ddd;
}
.center_container_share
{
	width: 640px;
	margin-left: auto;
	margin-right: auto;
	height: 130px;
	background:#ddd;
	margin-top: 2px;
	padding: 2px 6px 2px 6px;
	
}
#center_list
{
	float: left;
	padding:2px 4px 2px 4px;
	background: ;
	margin-right: 25px;

}
.container_ads
{
	width: 300px;
	height: 500px;
	background: #fff;
	border: 1px solid #ddd;
	box-shadow: 1px 2px 2px #ddd;
	padding: 2px 5px 2px 5px;

}
</style>
</head>
<body>
	 <?php
      
      foreach($info as $data)
  
        ?>
<nav>
<div class="container">
	<div class="row">
     <div class="col-md-8">
    <input type="text" class="form-control top_search" placeholder="Search"><span class="glyphicon glyphicon-search search_icon"></span>
     </div>
     <div class="col-md-4">
     	<div class="nav_right">
     		  <div class="left"><img src="http://sibilhussain.com/facebook-api/profile/<?php echo $info['pic']; ?>" class="" style="border-radius:2px;width:60px; height:50px;"></div>
              <div class="right"> <?php echo $info['email']; ?> </div>
     	</div>
     </div>
 </div>

</div> 
</nav>
<div class="wrapper">
<div class="container" style="margin-top:20px;">
	<div class="row">
	<div class="col-md-2">
    <ul>
    <li><img STYLE="width:20px; height:20px;" src="http://sibilhussain.com/facebook-api/profile/<?php echo $info['pic']; ?>" class="right_mrg"><?php echo $info['fname']; ?></li>
    <li><span class="glyphicon glyphicon-wrench right_mrg"></span>Edit Profile</li>
    <li><span class="glyphicon glyphicon-wrench right_mrg"></span><a href="http://sibilhussain.com/facebook-clone/index.php/Logincontroller/logout">LogOut</a></li>
    </ul>
	</div>
	<div class="col-md-7">
    <div class="center_container">
    <div class="center_container_row">
    <ul>
   <li id="center_list"><span style="background:#2196f3; padding:2px 2px 2px 2px; border-radius:2px; color:#fff;"class="glyphicon glyphicon-pencil right_mrg"></span>Update Status</li>
   <li id="center_list"><span style="background:#ffc107; padding:2px 2px 2px 2px; border-radius:2px; color:#fff;"class="glyphicon glyphicon-camera right_mrg"></span>Add Photo/Video</li>
   <li id="center_list"><span style="background:#4caf50; padding:2px 2px 2px 2px; border-radius:2px; color:#fff;"class="glyphicon glyphicon-font right_mrg"></span>Write Note</li>
    </ul>
    </div>
    <div class="center_container_share">
    	<div class="row">
          <div class="col-md-1">
       <img src="http://sibilhussain.com/facebook-api/profile/<?php echo $info['pic']; ?>" style="width:50px; height:50px;">
          </div>
          <div class="col-md-11"> 
          <textarea cols="76" rows="6"></textarea>
          </div>
    	</div>
    </div>
    </div>
	</div>
	<div class="col-md-3">
    <div class="container_ads">
     <h6>Ads Here</h6>
    </div>
	</div>
</div>
</div>
</div>
<footer id="foot_bg" style="    background: #fff;
    height: 150px;"> 
<div class="col-md-offset-2 col-md-8 col-md-offset-2 hidden-sm" style=";">
    <ul class="list-inline " style="border-bottom:0px solid #ddd;">
        <li>English</li>
        <li>മലയാളം</li>
        <li>தமிழ்</li>
        <li>English</li>
        <li>ಕನ್ನಡ</li> 
        <li>हिन्दी</li>
         </li>اردو</li>
          <li>বাংলা</li> 
        <li>తెలుగు</li>
         <li>Español</li>
         <li> Português (Brasil)</li>
    </ul>

<hr style="width: 100%; color: #AFA7A7; height: 1px; background-color:#AFA7A7;">
</div>
<div class="col-md-offset-2 col-md-8 col-md-offset-2 hidden-sm" style="">
    <ul class="list-inline " style="border-bottom:0px solid #ddd;">
        <li>Sign Up</li>
        <li>login</li>
        <li>Messenger</li>
        <li>Facebook</li>
        <li>Lite</li> 
        <li>Mobile</li>
         </li>Find Friend</li>
          <li>Badges</li> 
        <li>People</li>
         <li>Page</li>
         <li> Place</li>
         <li>Games</li>
         <li>Celebrities</li>
       <li>  Groups</li> <li>About  </li> <li>Create Advert</li>  <li> Create Page</li><li> Developers </li> <li>Careers </li> <li>Privacy Cookies</li> <li>AdChoices </li><li>Terms Help</li>
    </ul>
Facebook © 2016
</footer>
</body>
</html>