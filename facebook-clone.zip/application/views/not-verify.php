<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/myview.css">
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
<div class="header-top">
 <div div class="container">
     <div class="row">
     	  <div class="col-md-5 col-sm-12 col-xs-12">
               <img class="img-responsive" src="http://sibilhussain.com/facebook-clone/bootstrap/image/logo.png" height="" style="margin-top:-10px;">
     	  </div>
     </div>
 </div>
 </div>
 <div class="wrapper">
 	<div class="box-center">
 		<h3>Email Verification</h3>
 		<p>
       We sent an email to <b> <?php echo $data['USERNAME']; ?> </b> make sure tha your own it.Please check your inbox then visit the link to active your a/c thanks.
 		</p>
 		<a class="btn btn-primary center" href="<?php echo base_url(); ?>">SignIn</a>
 	</div>
</body>
</html>