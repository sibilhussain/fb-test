<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Maincl extends CI_Controller {

	
	public function index()
	{
		// HERE CHECK WHETHER THE SESSION EMPTY OR NOT
		if($this->session->has_userdata('ID'))
		{
			$ID = $this->session->userdata('ID');
			$info['ID'] = $ID;
			$url = 'http://sibilhussain.com/facebook-api/index.php/Mainview/';
		$options= array(
                 'http'=>array(
                          'header'=>"Content-type: application/x-www-form-urlencoded",
                          'method'=>'POST',
                          'content'=> http_build_query($info),
                 	),
			);
		$content = stream_context_create($options);
		$result= file_get_contents($url,false,$content);
	    $json=json_decode($result,true);
        $data['info'] = $json;
        $this->load->view("mainview",$data);
		}
		else
		{
			echo "<B>You have no permission to view this page</B>";
		}
	}
}
