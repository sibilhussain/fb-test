<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mainview extends CI_Controller {

	
	public function index()
	{
	
   $ID = $this->input->post('ID');
   // $msg = array('msg' =>$ID);

    $this->load->model('mainmodel');

    $data = new mainmodel();
    $msg = $data->dataget($ID);
    echo json_encode($msg);
   

	}
}
