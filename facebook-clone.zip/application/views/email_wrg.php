<?php
	$this->load->helper('url');

?>
<html>
<head>
<title>FACEBOOK</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/bootstrap.min.css">
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="http://sibilhussain.com/facebook-clone/bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://sibilhussain.com/facebook-clone/bootstrap/css/email_wrg.css">
 <?php
      
      foreach($data as $user)
  
        ?>

<head>
<body>
<nav>
 <div class="container">
      <div class="row">
           <div class="col-md-7 col-sm-12">
          <img src="http://sibilhussain.com/facebook-clone/bootstrap/image/logo.png" class="logo img-responsive">
            </div>
         
            </div>
      </div>
 </div>
</nav>
<div class="wrapper">
<div class="container" style="margin-top:50px;">
<div class="col-md-12">
<div class="msg"><?php echo $data['MSG'] ?></div>
<div class="main_container">
    <form action="<?php echo base_url() ?>Logincontroller/authuser" method="POST">
	<div class="main_row">FACEBOOK LOGIN</div>
	<div class="main_left">
    <label>Email Or Phone No:</label>
    <label>Password:</label>
	</div>
	<div class="main_right">
    <input type="text" name="email" class="form-control">
    <input type="password" name="password" class="form-control">
    <input type="checkbox"> <h6>Keep Me Logged</h6>
    <input type="submit" class="btn btn-primary" value="Login"> Or <a href="">SignUp For Facebook</a><br>
    <a href="">Forgotten Your Password</a>
</form>
	</div>
</div>

</div>
</div>
</div>
<footer id="foot_bg" style="    background: #fff;
    height: 150px;"> 
<div class="col-md-offset-1 col-md-10 col-md-offset-1 hidden-sm" style=";">
    <ul class="list-inline " style="border-bottom:0px solid #ddd;">
        <li>English</li>
        <li>മലയാളം</li>
        <li>தமிழ்</li>
        <li>English</li>
        <li>ಕನ್ನಡ</li> 
        <li>हिन्दी</li>
         </li>اردو</li>
          <li>বাংলা</li> 
        <li>తెలుగు</li>
         <li>Español</li>
         <li> Português (Brasil)</li>
    </ul>

<hr style="width: 100%; color: #AFA7A7; height: 1px; background-color:#AFA7A7;">
</div>
<div class="col-md-offset-1 col-md-10 col-md-offset-1 hidden-sm" style="">
    <ul class="list-inline " style="border-bottom:0px solid #ddd;">
        <li>Sign Up</li>
        <li>login</li>
        <li>Messenger</li>
        <li>Facebook</li>
        <li>Lite</li> 
        <li>Mobile</li>
         </li>Find Friend</li>
          <li>Badges</li> 
        <li>People</li>
         <li>Page</li>
         <li> Place</li>
         <li>Games</li>
         <li>Celebrities</li>
       <li>  Groups</li> <li>About  </li> <li>Create Advert</li>  <li> Create Page</li><li> Developers </li> <li>Careers </li> <li>Privacy Cookies</li> <li>AdChoices </li><li>Terms Help</li>
    </ul>
Facebook © 2016
</footer>

<body>
</html>