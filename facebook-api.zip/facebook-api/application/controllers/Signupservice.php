<?php

class Signupservice extends CI_Controller
{
	// variable declaration
	private $chr_fname;
	private $chr_lname;
	private $chr_email;
    private $int_pass;
    private $int_pass2;
    private $char_file_temp;
    private $int_date_m;
    private $int_date_d;
    private $int_date_y;
    private $gender;

    // main function
	public function index()
	{

		
    // assign values into variables
		$catch['chr_fname'] = $this->input->post('firstname');
		$catch['chr_lname'] = $this->input->post('lastname');
        $catch['chr_email'] = $this->input->post('email');
        $catch['chr_email2'] = $this->input->post('email2');
        $catch['int_pass'] = $this->input->post('password');
        $catch['int_day'] = $this->input->post('day');
        $catch['int_month'] = $this->input->post('month');
        $catch['int_year'] = $this->input->post('year');
        $catch['gender'] = $this->input->post('gender');
        $catch['file-tmp'] = $this->input->post('file-tmp');
        $catch['file-name'] = $this->input->post('file-name');
        $catch['file-size'] = $this->input->post('file-size');
        $catch['file-type'] = $this->input->post('file-type');
	  // here check empty fields
        if(!empty($catch['chr_fname']) and !empty($catch['chr_lname']) and !empty($catch['chr_email']) and !empty($catch['chr_email2']) and !empty($catch['int_pass']) and !empty($catch['int_year']) and !empty($catch['int_month']) and !empty($catch['int_day']) and !empty($catch['gender']))
        {
      // check profile pic is empty or not      
        if (!empty($catch['file-tmp'])) {
//            check uploaded file is image or not
            if($catch['file-type'] =='image/gif' || $catch['file-type'] == 'image/jpeg' || $catch['file-type'] == 'image/png')
           {
             // check image size
               if($catch['file-size'] > 5242880)
                  {
                  $response = array('Respose' => 'Profile Pic Not Allowede <5mb');     
                  }
               else
               {

                if(strlen($catch['chr_fname'])< 3)
                {
                  $response = array('Respose' => 'Name Required at least 3 letters');
                }
                 else
                 {
                // password validation
                if(!preg_match("#[0-9]+#",$catch['int_pass']))
                {
                  $response = array('Respose' => 'Password Required At Least One Digit');
                }
                elseif(!preg_match("#[A-Z]+#",$catch['int_pass'])) {
               $response = array('Respose' => 'Password Required At Least One Capital letter');
                }  
                elseif(!preg_match('/[\d!$%^&]+/', $catch['int_pass']))
                {
                  $response = array('Respose' => 'Password Required At Least One Capital Symbol');
             
                }
                elseif(strlen($catch['int_pass']) < 8)
                 {
                     $response = array('Respose' => 'Pass required at least 8 letters');
                 }
                 else
                 {
                    // DOB VALIDATION
                   $date =date("Y");
                   $age = $date - $catch['int_year'];
                      if($age < 13)
                      {
                        $response = array('Respose' => 'ony Alloweded at least 13 years old');      
                      }
                      else
                      {
                        // email validation
                        if(!filter_var($catch['chr_email'], FILTER_VALIDATE_EMAIL))
                        {
                        $response = array('Respose' => 'Invalid Email Formate');
                         }
                         else
                         {
                            if (!$catch['chr_email'] == $catch['chr_email2']) {
                            $response = array('Respose' => 're-entered mail not matched');    
                            }
                            else
                            {
                              
                          $this->load->model("Signupmodel");
                                
                          $result = $this->Signupmodel->signauth($catch);
                          
                        
                        if($result['code']==404)
                          {
                            $session_data =$this->session->userdata['hashkey'];
                           
                              $value['to'] =$result['email'];
                              $value['body'] ='http://sibilhussain.com/facebook-api/index.php/Verify/?key='.$session_data;
                   // mail function use to send verification mail 
                              if($this->mailer($value))
                              {
                                $response = array('Respose' => 'Sended email');
                              }
                              else
                              {
                                $response = array('Respose' => 'Failed !');
                              }
                                                             
                          }
                          elseif($result['code']==303)
                          {
                                   $response = array('Respose' => 'Failed !');
                          }
                          else
                          {
                             $response = array('Respose' =>$result['Respones'],'code'=> $result['code']);
                          }

                            }
                         }

                      }
                 }
                }
               }
           }
           else{
                $response = array('Respose' => 'Only Alloweded these types gif||jpg||png');
           }  

        }
        else
        {
        $response = array('Respose' => 'Choose Profile Pic');       
        }
        
        }
     else{
        $response = array('Respose' => 'Fill All Colums');
     }
        
  
        echo json_encode($response);
	}

public function mailer($value)
{

  $this->load->library('email');

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'host';
$config['smtp_user'] = 'admin@sibilhussain.com';
$config['smtp_pass'] = 'pass';
$config['smtp_port'] = 587;

$this->email->initialize($config);

$this->email->from('admin@sibilhussain.com');
$this->email->to($value['to']);
$this->email->subject('Test');
$this->email->message($value['body']);

if($this->email->send()) {
     return true;
} else {
     return false;
}

}

}

?>