<?php
class verifymodel extends CI_Model
{
    
	public function verification($datas)
	{
		// echo $datas['key'];
        $this->load->database();
        $query=$this->db->select('int_id,vchr_email')
                ->from('tbl_user')
                ->where('vchr_hash_key',$datas['key'])
                ->get();
        if($query->num_rows()==1)
        {
   
        foreach ($query->result() as $row)
         {
        $int_id = $row->int_id;
        $vchr_email = $row->vchr_email;
         }   
         $this->db->set('status', 'true');
         $this->db->where('int_id',$int_id);
         $this->db->update('tbl_user');
         $response  = array('msg' =>'verified','code'=>'404','email'=>$vchr_email);
		}
        else
        {
             $response  = array('msg' =>'Not verified','code'=>'303');
        }
     return $response;
	}
}
?>