<?php
class loginmodel extends CI_Model
{

	public function userauth($value)
	{
		$this->load->database();
		$query=$this->db->select('int_id,vchr_email,status')
				->from('tbl_user')
				->where($value)
				->get();
		if($query->num_rows()==1)
		{
           foreach ($query->result() as $row)
         {
        $int_id = $row->int_id;
        $vchr_email = $row->vchr_email;
        $status = $row->status;
         }   
         $msg = array('RESPOND' =>'500','MSG'=>'Success','USERNAME'=>$vchr_email,'PIC'=>'','FIRSTNAME'=>'','LASTNAME'=>'','ID'=>$int_id,'STATUS'=>$status);
                     
         }
		else
		{
        $qry2 = $this->db->select('int_id,vchr_email,int_pic,chr_fname,chr_lname')->from('tbl_user')->where('vchr_email',$value['vchr_email'])->get();

         if($qry2->num_rows()==1)
         {
         		foreach ($qry2->result() as $row)
                {
         		$username = $row->vchr_email;
         		$firstname =$row->chr_fname;
                $lastname = $row->chr_lname;
         		$pic=$row->int_pic;
            }


         	$msg = array('RESPOND' =>'300','MSG'=>'Password incorrect','USERNAME'=>$username,'PIC'=>$pic,'FIRSTNAME'=>$firstname,'LASTNAME'=>$lastname);
         	
         }
         else
         {
         	$msg = array('RESPOND' =>'400','MSG'=>'incorrected pass and user');
         
         }
         
		}
                return $msg;
		
	}
}
?>