-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Sep 27, 2016 at 11:10 AM
-- Server version: 5.5.45-37.4-log
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `filebirb_sibil`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`filebirb`@`localhost` PROCEDURE `insertval`(IN `email` VARCHAR(40), IN `pass` VARCHAR(40), IN `fname` CHAR(20), IN `lname` CHAR(20), IN `db` VARCHAR(20), IN `gender` CHAR(20), IN `status` CHAR(20), IN `pic` VARCHAR(70), IN `hashkey` VARCHAR(70))
BEGIN
INSERT INTO tbl_user(vchr_email,varchar_pass,chr_fname,chr_lname,dob,chr_gender,status,int_pic,vchr_hash_key) VALUES(email,pass,fname,lname,db,gender,status,pic,hashkey);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `int_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_email` varchar(30) NOT NULL,
  `varchar_pass` varchar(30) NOT NULL,
  `chr_fname` char(25) NOT NULL,
  `chr_lname` char(20) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `chr_gender` char(10) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'false',
  `int_pic` varchar(60) DEFAULT NULL,
  `vchr_hash_key` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`int_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=81 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`int_id`, `vchr_email`, `varchar_pass`, `chr_fname`, `chr_lname`, `dob`, `chr_gender`, `status`, `int_pic`, `vchr_hash_key`) VALUES
(73, 'musthafamuze@gmail.com', 'ABCD123456', 'musthafa', 'NEWBE', '1999/Feb/19', 'male', 'false', 'ae3b6590fc2d5cecebca4676a590550d .png', 'ae3b6590fc2d5cecebca4676a590550d'),
(79, 'sibilhussain@gmail.com', 'asdasdA555151', 'sibil', 'Hussain', '1998/Dec/18', 'male', 'true', '48f5600565358dcb54611f8a9c4ffd39 .png', '48f5600565358dcb54611f8a9c4ffd39'),
(80, 'spsp89@gmail.com', '123123a123A', 'sharan', 'p', '1978/Oct/9', 'male', 'true', 'ef8113d7f731b2ad636a8d99b3e84d3a .jpg', 'ef8113d7f731b2ad636a8d99b3e84d3a');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
