<?php

class Signupcontroller extends CI_Controller
{
	
   public function index()
   {
//    ASSIGN  VALUEs INTO ARRAY
     $details['firstname'] = $this->input->get_post('chr_name');
     $details['lastname'] = $this->input->get_post('chr_last_name');
     $details['email'] = $this->input->get_post('chr_email');
     $details['email2'] = $this->input->get_post('chr_chr_re_email');
     $details['password'] = $this->input->get_post('pass');
     $details['day'] = $this->input->get_post('day');
     $details['month'] = $this->input->get_post('month');
     $details['year'] = $this->input->get_post('year');
     $details['gender'] = $this->input->get_post('gender');
     if(empty($_FILES['profile_pic']['tmp_name']))
     {
     $_FILES['profile_pic']['tmp_name']="";
     $_FILES['profile_pic']['name']="";
     $_FILES['profile_pic']['size']="";
     $_FILES['profile_pic']['type']="";
     }
     else{
     $details['file-tmp'] = $_FILES['profile_pic']['tmp_name'];
     $details['file-name'] = $_FILES['profile_pic']['name'];
     $details['file-size'] = $_FILES['profile_pic']['size'];
      $details['file-type'] = $_FILES['profile_pic']['type'];
      }
   // $ext = '.'.pathinfo($details['file-name'], PATHINFO_EXTENSION);
      
     // print_r($details);
     $url = 'http://sibilhussain.com/facebook-api/index.php/Signupservice';
		$options= array(
                 'http'=>array(
                          'header'=>"Content-type: application/x-www-form-urlencoded",
                          'method'=>'POST',
                          'content'=> http_build_query($details),
                 	),
			);
		$content = stream_context_create($options);
		$result= file_get_contents($url,false,$content);
	   $json=json_decode($result,true);

   $user['msg'] = $json;
      
      $this->load->view('myview',$user);
   }

}


?>