<?php
class Mainmodel extends CI_Model
{

 public function dataget($ID)
 {
 	$get = array('int_id' => $ID);
$this->load->database();
		$query=$this->db->select('int_id,vchr_email,status,chr_fname,chr_lname,dob,int_pic')
				->from('tbl_user')
				->where($get)
				->get();

foreach ($query->result() as $row)
{
        $email = $row->vchr_email;
        $fname = $row->chr_fname;
        $lname = $row->chr_lname;
        $int_pic = $row->int_pic;
}
 	$msg = array('email' =>$email,'fname'=>$fname,'lname'=>$lname,'pic'=>$int_pic);

 	return $msg;
 }
  
}
?>