<?php
date_default_timezone_set('Etc/UTC');
require '../PHPMailerAutoload.php';
$mail = new PHPMailer;
$mail->SMTPAuth = true; 
$mail->Host = "smtp.mail.yahoo.com";
$mail->Port = 587; 
$mail->Username = "muhsintheblogger@yahoo.com"; 
$mail->Password = "9287393415"; 
$mail->isSMTP();
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->setFrom('muhsintheblogger@yahoo.com', 'First Last');
$mail->addReplyTo('muhsintheblogger@yahoo.com', 'First Last');
$mail->addAddress('waphunt@gmail.com', 'John Doe');
$mail->Subject = 'PHPMailer GMail SMTP test';
$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
$mail->AltBody = 'This is a plain-text message body';
$mail->addAttachment('images/phpmailer_mini.png');
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}
?>