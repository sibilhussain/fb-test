<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-28 06:34:49 --> Config Class Initialized
INFO - 2016-09-28 06:34:49 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:34:50 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:34:50 --> Utf8 Class Initialized
INFO - 2016-09-28 06:34:50 --> URI Class Initialized
DEBUG - 2016-09-28 06:34:50 --> No URI present. Default controller set.
INFO - 2016-09-28 06:34:50 --> Router Class Initialized
INFO - 2016-09-28 06:34:50 --> Output Class Initialized
INFO - 2016-09-28 06:34:50 --> Security Class Initialized
DEBUG - 2016-09-28 06:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:34:50 --> Input Class Initialized
INFO - 2016-09-28 06:34:50 --> Language Class Initialized
INFO - 2016-09-28 06:34:50 --> Loader Class Initialized
INFO - 2016-09-28 06:34:50 --> Helper loaded: url_helper
INFO - 2016-09-28 06:34:50 --> Helper loaded: file_helper
INFO - 2016-09-28 06:34:50 --> Helper loaded: form_helper
INFO - 2016-09-28 06:34:50 --> Database Driver Class Initialized
INFO - 2016-09-28 06:34:50 --> Email Class Initialized
INFO - 2016-09-28 06:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:34:50 --> Controller Class Initialized
INFO - 2016-09-28 06:34:50 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/myview.php
INFO - 2016-09-28 06:34:50 --> Final output sent to browser
DEBUG - 2016-09-28 06:34:50 --> Total execution time: 0.4757
INFO - 2016-09-28 06:34:59 --> Config Class Initialized
INFO - 2016-09-28 06:34:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:34:59 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:34:59 --> Utf8 Class Initialized
INFO - 2016-09-28 06:34:59 --> URI Class Initialized
INFO - 2016-09-28 06:34:59 --> Router Class Initialized
INFO - 2016-09-28 06:34:59 --> Output Class Initialized
INFO - 2016-09-28 06:34:59 --> Security Class Initialized
DEBUG - 2016-09-28 06:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:34:59 --> Input Class Initialized
INFO - 2016-09-28 06:34:59 --> Language Class Initialized
INFO - 2016-09-28 06:34:59 --> Loader Class Initialized
INFO - 2016-09-28 06:34:59 --> Helper loaded: url_helper
INFO - 2016-09-28 06:34:59 --> Helper loaded: file_helper
INFO - 2016-09-28 06:34:59 --> Helper loaded: form_helper
INFO - 2016-09-28 06:34:59 --> Database Driver Class Initialized
INFO - 2016-09-28 06:34:59 --> Email Class Initialized
INFO - 2016-09-28 06:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:34:59 --> Controller Class Initialized
INFO - 2016-09-28 06:35:01 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/pass_wrg.php
INFO - 2016-09-28 06:35:01 --> Final output sent to browser
DEBUG - 2016-09-28 06:35:01 --> Total execution time: 1.8621
INFO - 2016-09-28 06:36:54 --> Config Class Initialized
INFO - 2016-09-28 06:36:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:36:54 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:36:54 --> Utf8 Class Initialized
INFO - 2016-09-28 06:36:54 --> URI Class Initialized
INFO - 2016-09-28 06:36:54 --> Router Class Initialized
INFO - 2016-09-28 06:36:54 --> Output Class Initialized
INFO - 2016-09-28 06:36:54 --> Security Class Initialized
DEBUG - 2016-09-28 06:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:36:54 --> Input Class Initialized
INFO - 2016-09-28 06:36:54 --> Language Class Initialized
INFO - 2016-09-28 06:36:54 --> Loader Class Initialized
INFO - 2016-09-28 06:36:54 --> Helper loaded: url_helper
INFO - 2016-09-28 06:36:54 --> Helper loaded: file_helper
INFO - 2016-09-28 06:36:54 --> Helper loaded: form_helper
INFO - 2016-09-28 06:36:54 --> Database Driver Class Initialized
INFO - 2016-09-28 06:36:54 --> Email Class Initialized
INFO - 2016-09-28 06:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:36:54 --> Controller Class Initialized
INFO - 2016-09-28 06:36:55 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/pass_wrg.php
INFO - 2016-09-28 06:36:55 --> Final output sent to browser
DEBUG - 2016-09-28 06:36:55 --> Total execution time: 1.2106
INFO - 2016-09-28 06:39:16 --> Config Class Initialized
INFO - 2016-09-28 06:39:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:39:16 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:39:16 --> Utf8 Class Initialized
INFO - 2016-09-28 06:39:16 --> URI Class Initialized
INFO - 2016-09-28 06:39:16 --> Router Class Initialized
INFO - 2016-09-28 06:39:16 --> Output Class Initialized
INFO - 2016-09-28 06:39:16 --> Security Class Initialized
DEBUG - 2016-09-28 06:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:39:16 --> Input Class Initialized
INFO - 2016-09-28 06:39:16 --> Language Class Initialized
INFO - 2016-09-28 06:39:16 --> Loader Class Initialized
INFO - 2016-09-28 06:39:16 --> Helper loaded: url_helper
INFO - 2016-09-28 06:39:16 --> Helper loaded: file_helper
INFO - 2016-09-28 06:39:16 --> Helper loaded: form_helper
INFO - 2016-09-28 06:39:16 --> Database Driver Class Initialized
INFO - 2016-09-28 06:39:16 --> Email Class Initialized
INFO - 2016-09-28 06:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:39:17 --> Controller Class Initialized
INFO - 2016-09-28 06:39:18 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/pass_wrg.php
INFO - 2016-09-28 06:39:18 --> Final output sent to browser
DEBUG - 2016-09-28 06:39:18 --> Total execution time: 1.1812
INFO - 2016-09-28 06:41:09 --> Config Class Initialized
INFO - 2016-09-28 06:41:09 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:41:09 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:41:09 --> Utf8 Class Initialized
INFO - 2016-09-28 06:41:09 --> URI Class Initialized
INFO - 2016-09-28 06:41:09 --> Router Class Initialized
INFO - 2016-09-28 06:41:09 --> Output Class Initialized
INFO - 2016-09-28 06:41:09 --> Security Class Initialized
DEBUG - 2016-09-28 06:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:41:09 --> Input Class Initialized
INFO - 2016-09-28 06:41:09 --> Language Class Initialized
INFO - 2016-09-28 06:41:09 --> Loader Class Initialized
INFO - 2016-09-28 06:41:09 --> Helper loaded: url_helper
INFO - 2016-09-28 06:41:09 --> Helper loaded: file_helper
INFO - 2016-09-28 06:41:09 --> Helper loaded: form_helper
INFO - 2016-09-28 06:41:09 --> Database Driver Class Initialized
INFO - 2016-09-28 06:41:09 --> Email Class Initialized
INFO - 2016-09-28 06:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:41:09 --> Controller Class Initialized
INFO - 2016-09-28 06:41:10 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/pass_wrg.php
INFO - 2016-09-28 06:41:10 --> Final output sent to browser
DEBUG - 2016-09-28 06:41:10 --> Total execution time: 1.1989
INFO - 2016-09-28 06:41:16 --> Config Class Initialized
INFO - 2016-09-28 06:41:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:41:16 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:41:16 --> Utf8 Class Initialized
INFO - 2016-09-28 06:41:16 --> URI Class Initialized
INFO - 2016-09-28 06:41:16 --> Router Class Initialized
INFO - 2016-09-28 06:41:16 --> Output Class Initialized
INFO - 2016-09-28 06:41:16 --> Security Class Initialized
DEBUG - 2016-09-28 06:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:41:16 --> Input Class Initialized
INFO - 2016-09-28 06:41:16 --> Language Class Initialized
INFO - 2016-09-28 06:41:16 --> Loader Class Initialized
INFO - 2016-09-28 06:41:16 --> Helper loaded: url_helper
INFO - 2016-09-28 06:41:16 --> Helper loaded: file_helper
INFO - 2016-09-28 06:41:16 --> Helper loaded: form_helper
INFO - 2016-09-28 06:41:16 --> Database Driver Class Initialized
INFO - 2016-09-28 06:41:16 --> Email Class Initialized
INFO - 2016-09-28 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:41:16 --> Controller Class Initialized
ERROR - 2016-09-28 06:41:16 --> Severity: Warning --> file_get_contents(http://sibilhussain.com/facebook-api/index.php/Loginservice/login): failed to open stream: HTTP request failed! HTTP/1.1 406 Not Acceptable
 /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 23
INFO - 2016-09-28 06:41:16 --> Final output sent to browser
DEBUG - 2016-09-28 06:41:16 --> Total execution time: 0.0808
INFO - 2016-09-28 06:41:43 --> Config Class Initialized
INFO - 2016-09-28 06:41:43 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:41:43 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:41:43 --> Utf8 Class Initialized
INFO - 2016-09-28 06:41:43 --> URI Class Initialized
DEBUG - 2016-09-28 06:41:43 --> No URI present. Default controller set.
INFO - 2016-09-28 06:41:43 --> Router Class Initialized
INFO - 2016-09-28 06:41:43 --> Output Class Initialized
INFO - 2016-09-28 06:41:43 --> Security Class Initialized
DEBUG - 2016-09-28 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:41:43 --> Input Class Initialized
INFO - 2016-09-28 06:41:43 --> Language Class Initialized
INFO - 2016-09-28 06:41:43 --> Loader Class Initialized
INFO - 2016-09-28 06:41:43 --> Helper loaded: url_helper
INFO - 2016-09-28 06:41:43 --> Helper loaded: file_helper
INFO - 2016-09-28 06:41:43 --> Helper loaded: form_helper
INFO - 2016-09-28 06:41:43 --> Database Driver Class Initialized
INFO - 2016-09-28 06:41:43 --> Email Class Initialized
INFO - 2016-09-28 06:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:41:43 --> Controller Class Initialized
INFO - 2016-09-28 06:41:43 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/myview.php
INFO - 2016-09-28 06:41:43 --> Final output sent to browser
DEBUG - 2016-09-28 06:41:43 --> Total execution time: 0.0349
INFO - 2016-09-28 06:41:50 --> Config Class Initialized
INFO - 2016-09-28 06:41:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:41:50 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:41:50 --> Utf8 Class Initialized
INFO - 2016-09-28 06:41:50 --> URI Class Initialized
INFO - 2016-09-28 06:41:50 --> Router Class Initialized
INFO - 2016-09-28 06:41:50 --> Output Class Initialized
INFO - 2016-09-28 06:41:50 --> Security Class Initialized
DEBUG - 2016-09-28 06:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:41:50 --> Input Class Initialized
INFO - 2016-09-28 06:41:50 --> Language Class Initialized
INFO - 2016-09-28 06:41:50 --> Loader Class Initialized
INFO - 2016-09-28 06:41:50 --> Helper loaded: url_helper
INFO - 2016-09-28 06:41:50 --> Helper loaded: file_helper
INFO - 2016-09-28 06:41:50 --> Helper loaded: form_helper
INFO - 2016-09-28 06:41:50 --> Database Driver Class Initialized
INFO - 2016-09-28 06:41:51 --> Email Class Initialized
INFO - 2016-09-28 06:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:41:51 --> Controller Class Initialized
INFO - 2016-09-28 06:41:51 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/pass_wrg.php
INFO - 2016-09-28 06:41:51 --> Final output sent to browser
DEBUG - 2016-09-28 06:41:51 --> Total execution time: 0.0979
INFO - 2016-09-28 06:41:58 --> Config Class Initialized
INFO - 2016-09-28 06:41:58 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:41:58 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:41:58 --> Utf8 Class Initialized
INFO - 2016-09-28 06:41:58 --> URI Class Initialized
INFO - 2016-09-28 06:41:58 --> Router Class Initialized
INFO - 2016-09-28 06:41:58 --> Output Class Initialized
INFO - 2016-09-28 06:41:58 --> Security Class Initialized
DEBUG - 2016-09-28 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:41:58 --> Input Class Initialized
INFO - 2016-09-28 06:41:58 --> Language Class Initialized
INFO - 2016-09-28 06:41:58 --> Loader Class Initialized
INFO - 2016-09-28 06:41:58 --> Helper loaded: url_helper
INFO - 2016-09-28 06:41:58 --> Helper loaded: file_helper
INFO - 2016-09-28 06:41:58 --> Helper loaded: form_helper
INFO - 2016-09-28 06:41:58 --> Database Driver Class Initialized
INFO - 2016-09-28 06:41:58 --> Email Class Initialized
INFO - 2016-09-28 06:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:41:58 --> Controller Class Initialized
ERROR - 2016-09-28 06:41:58 --> Severity: Warning --> file_get_contents(http://sibilhussain.com/facebook-api/index.php/Loginservice/login): failed to open stream: HTTP request failed! HTTP/1.1 406 Not Acceptable
 /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 23
INFO - 2016-09-28 06:41:58 --> Final output sent to browser
DEBUG - 2016-09-28 06:41:58 --> Total execution time: 0.0449
INFO - 2016-09-28 06:42:04 --> Config Class Initialized
INFO - 2016-09-28 06:42:04 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:42:04 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:42:04 --> Utf8 Class Initialized
INFO - 2016-09-28 06:42:04 --> URI Class Initialized
DEBUG - 2016-09-28 06:42:04 --> No URI present. Default controller set.
INFO - 2016-09-28 06:42:04 --> Router Class Initialized
INFO - 2016-09-28 06:42:04 --> Output Class Initialized
INFO - 2016-09-28 06:42:04 --> Security Class Initialized
DEBUG - 2016-09-28 06:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:42:04 --> Input Class Initialized
INFO - 2016-09-28 06:42:04 --> Language Class Initialized
INFO - 2016-09-28 06:42:04 --> Loader Class Initialized
INFO - 2016-09-28 06:42:04 --> Helper loaded: url_helper
INFO - 2016-09-28 06:42:04 --> Helper loaded: file_helper
INFO - 2016-09-28 06:42:04 --> Helper loaded: form_helper
INFO - 2016-09-28 06:42:04 --> Database Driver Class Initialized
INFO - 2016-09-28 06:42:04 --> Email Class Initialized
INFO - 2016-09-28 06:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:42:04 --> Controller Class Initialized
INFO - 2016-09-28 06:42:04 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/myview.php
INFO - 2016-09-28 06:42:04 --> Final output sent to browser
DEBUG - 2016-09-28 06:42:04 --> Total execution time: 0.0355
INFO - 2016-09-28 06:43:00 --> Config Class Initialized
INFO - 2016-09-28 06:43:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:43:00 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:43:00 --> Utf8 Class Initialized
INFO - 2016-09-28 06:43:00 --> URI Class Initialized
INFO - 2016-09-28 06:43:00 --> Router Class Initialized
INFO - 2016-09-28 06:43:00 --> Output Class Initialized
INFO - 2016-09-28 06:43:00 --> Security Class Initialized
DEBUG - 2016-09-28 06:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:43:00 --> Input Class Initialized
INFO - 2016-09-28 06:43:00 --> Language Class Initialized
INFO - 2016-09-28 06:43:00 --> Loader Class Initialized
INFO - 2016-09-28 06:43:00 --> Helper loaded: url_helper
INFO - 2016-09-28 06:43:00 --> Helper loaded: file_helper
INFO - 2016-09-28 06:43:00 --> Helper loaded: form_helper
INFO - 2016-09-28 06:43:00 --> Database Driver Class Initialized
INFO - 2016-09-28 06:43:00 --> Email Class Initialized
INFO - 2016-09-28 06:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:43:00 --> Controller Class Initialized
INFO - 2016-09-28 06:43:00 --> Final output sent to browser
DEBUG - 2016-09-28 06:43:00 --> Total execution time: 0.1098
INFO - 2016-09-28 06:43:00 --> Config Class Initialized
INFO - 2016-09-28 06:43:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:43:00 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:43:00 --> Utf8 Class Initialized
INFO - 2016-09-28 06:43:00 --> URI Class Initialized
INFO - 2016-09-28 06:43:00 --> Router Class Initialized
INFO - 2016-09-28 06:43:00 --> Output Class Initialized
INFO - 2016-09-28 06:43:00 --> Security Class Initialized
DEBUG - 2016-09-28 06:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:43:00 --> Input Class Initialized
INFO - 2016-09-28 06:43:00 --> Language Class Initialized
INFO - 2016-09-28 06:43:00 --> Loader Class Initialized
INFO - 2016-09-28 06:43:00 --> Helper loaded: url_helper
INFO - 2016-09-28 06:43:00 --> Helper loaded: file_helper
INFO - 2016-09-28 06:43:00 --> Helper loaded: form_helper
INFO - 2016-09-28 06:43:00 --> Database Driver Class Initialized
INFO - 2016-09-28 06:43:00 --> Email Class Initialized
INFO - 2016-09-28 06:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:43:00 --> Controller Class Initialized
INFO - 2016-09-28 06:43:00 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/mainview.php
INFO - 2016-09-28 06:43:00 --> Final output sent to browser
DEBUG - 2016-09-28 06:43:00 --> Total execution time: 0.2101
INFO - 2016-09-28 06:43:09 --> Config Class Initialized
INFO - 2016-09-28 06:43:09 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:43:09 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:43:09 --> Utf8 Class Initialized
INFO - 2016-09-28 06:43:09 --> URI Class Initialized
INFO - 2016-09-28 06:43:09 --> Router Class Initialized
INFO - 2016-09-28 06:43:09 --> Output Class Initialized
INFO - 2016-09-28 06:43:09 --> Security Class Initialized
DEBUG - 2016-09-28 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:43:09 --> Input Class Initialized
INFO - 2016-09-28 06:43:09 --> Language Class Initialized
INFO - 2016-09-28 06:43:09 --> Loader Class Initialized
INFO - 2016-09-28 06:43:09 --> Helper loaded: url_helper
INFO - 2016-09-28 06:43:09 --> Helper loaded: file_helper
INFO - 2016-09-28 06:43:09 --> Helper loaded: form_helper
INFO - 2016-09-28 06:43:09 --> Database Driver Class Initialized
INFO - 2016-09-28 06:43:09 --> Email Class Initialized
INFO - 2016-09-28 06:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:43:09 --> Controller Class Initialized
INFO - 2016-09-28 06:43:09 --> Final output sent to browser
DEBUG - 2016-09-28 06:43:09 --> Total execution time: 0.0356
INFO - 2016-09-28 06:43:10 --> Config Class Initialized
INFO - 2016-09-28 06:43:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:43:10 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:43:10 --> Utf8 Class Initialized
INFO - 2016-09-28 06:43:10 --> URI Class Initialized
DEBUG - 2016-09-28 06:43:10 --> No URI present. Default controller set.
INFO - 2016-09-28 06:43:10 --> Router Class Initialized
INFO - 2016-09-28 06:43:10 --> Output Class Initialized
INFO - 2016-09-28 06:43:10 --> Security Class Initialized
DEBUG - 2016-09-28 06:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:43:10 --> Input Class Initialized
INFO - 2016-09-28 06:43:10 --> Language Class Initialized
INFO - 2016-09-28 06:43:10 --> Loader Class Initialized
INFO - 2016-09-28 06:43:10 --> Helper loaded: url_helper
INFO - 2016-09-28 06:43:10 --> Helper loaded: file_helper
INFO - 2016-09-28 06:43:10 --> Helper loaded: form_helper
INFO - 2016-09-28 06:43:10 --> Database Driver Class Initialized
INFO - 2016-09-28 06:43:10 --> Email Class Initialized
INFO - 2016-09-28 06:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:43:10 --> Controller Class Initialized
INFO - 2016-09-28 06:43:10 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/myview.php
INFO - 2016-09-28 06:43:10 --> Final output sent to browser
DEBUG - 2016-09-28 06:43:10 --> Total execution time: 0.0451
INFO - 2016-09-28 06:43:21 --> Config Class Initialized
INFO - 2016-09-28 06:43:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:43:21 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:43:21 --> Utf8 Class Initialized
INFO - 2016-09-28 06:43:21 --> URI Class Initialized
INFO - 2016-09-28 06:43:21 --> Router Class Initialized
INFO - 2016-09-28 06:43:21 --> Output Class Initialized
INFO - 2016-09-28 06:43:21 --> Security Class Initialized
DEBUG - 2016-09-28 06:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:43:21 --> Input Class Initialized
INFO - 2016-09-28 06:43:21 --> Language Class Initialized
INFO - 2016-09-28 06:43:21 --> Loader Class Initialized
INFO - 2016-09-28 06:43:21 --> Helper loaded: url_helper
INFO - 2016-09-28 06:43:21 --> Helper loaded: file_helper
INFO - 2016-09-28 06:43:21 --> Helper loaded: form_helper
INFO - 2016-09-28 06:43:21 --> Database Driver Class Initialized
INFO - 2016-09-28 06:43:21 --> Email Class Initialized
INFO - 2016-09-28 06:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:43:21 --> Controller Class Initialized
ERROR - 2016-09-28 06:43:21 --> Severity: Warning --> file_get_contents(http://sibilhussain.com/facebook-api/index.php/Loginservice/login): failed to open stream: HTTP request failed! HTTP/1.1 406 Not Acceptable
 /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 23
INFO - 2016-09-28 06:43:21 --> Final output sent to browser
DEBUG - 2016-09-28 06:43:21 --> Total execution time: 0.0437
INFO - 2016-09-28 06:46:22 --> Config Class Initialized
INFO - 2016-09-28 06:46:22 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:46:22 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:46:22 --> Utf8 Class Initialized
INFO - 2016-09-28 06:46:22 --> URI Class Initialized
INFO - 2016-09-28 06:46:22 --> Router Class Initialized
INFO - 2016-09-28 06:46:22 --> Output Class Initialized
INFO - 2016-09-28 06:46:22 --> Security Class Initialized
DEBUG - 2016-09-28 06:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:46:22 --> Input Class Initialized
INFO - 2016-09-28 06:46:22 --> Language Class Initialized
ERROR - 2016-09-28 06:46:22 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 8
INFO - 2016-09-28 06:47:21 --> Config Class Initialized
INFO - 2016-09-28 06:47:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:47:21 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:47:21 --> Utf8 Class Initialized
INFO - 2016-09-28 06:47:21 --> URI Class Initialized
INFO - 2016-09-28 06:47:21 --> Router Class Initialized
INFO - 2016-09-28 06:47:21 --> Output Class Initialized
INFO - 2016-09-28 06:47:21 --> Security Class Initialized
DEBUG - 2016-09-28 06:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:47:21 --> Input Class Initialized
INFO - 2016-09-28 06:47:21 --> Language Class Initialized
INFO - 2016-09-28 06:47:21 --> Loader Class Initialized
INFO - 2016-09-28 06:47:21 --> Helper loaded: url_helper
INFO - 2016-09-28 06:47:21 --> Helper loaded: file_helper
INFO - 2016-09-28 06:47:21 --> Helper loaded: form_helper
INFO - 2016-09-28 06:47:21 --> Database Driver Class Initialized
INFO - 2016-09-28 06:47:21 --> Email Class Initialized
INFO - 2016-09-28 06:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:47:21 --> Controller Class Initialized
ERROR - 2016-09-28 06:47:21 --> Severity: Notice --> Undefined variable: user /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 25
ERROR - 2016-09-28 06:47:21 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 25
ERROR - 2016-09-28 06:47:21 --> Severity: Warning --> file_get_contents(http://sibilhussain.com/facebook-api/index.php/Loginservice/login): failed to open stream: HTTP request failed! HTTP/1.1 406 Not Acceptable
 /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 29
INFO - 2016-09-28 06:47:21 --> Final output sent to browser
DEBUG - 2016-09-28 06:47:21 --> Total execution time: 0.1080
INFO - 2016-09-28 06:48:51 --> Config Class Initialized
INFO - 2016-09-28 06:48:51 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:48:51 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:48:51 --> Utf8 Class Initialized
INFO - 2016-09-28 06:48:51 --> URI Class Initialized
INFO - 2016-09-28 06:48:51 --> Router Class Initialized
INFO - 2016-09-28 06:48:51 --> Output Class Initialized
INFO - 2016-09-28 06:48:51 --> Security Class Initialized
DEBUG - 2016-09-28 06:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:48:51 --> Input Class Initialized
INFO - 2016-09-28 06:48:51 --> Language Class Initialized
INFO - 2016-09-28 06:48:51 --> Loader Class Initialized
INFO - 2016-09-28 06:48:51 --> Helper loaded: url_helper
INFO - 2016-09-28 06:48:51 --> Helper loaded: file_helper
INFO - 2016-09-28 06:48:51 --> Helper loaded: form_helper
INFO - 2016-09-28 06:48:51 --> Database Driver Class Initialized
INFO - 2016-09-28 06:48:51 --> Email Class Initialized
INFO - 2016-09-28 06:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:48:51 --> Controller Class Initialized
ERROR - 2016-09-28 06:48:51 --> Severity: Warning --> file_get_contents(http://sibilhussain.com/facebook-api/index.php/Loginservice/login): failed to open stream: HTTP request failed! HTTP/1.1 406 Not Acceptable
 /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 29
INFO - 2016-09-28 06:48:51 --> Final output sent to browser
DEBUG - 2016-09-28 06:48:51 --> Total execution time: 0.0466
INFO - 2016-09-28 06:49:57 --> Config Class Initialized
INFO - 2016-09-28 06:49:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:49:57 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:49:57 --> Utf8 Class Initialized
INFO - 2016-09-28 06:49:57 --> URI Class Initialized
INFO - 2016-09-28 06:49:57 --> Router Class Initialized
INFO - 2016-09-28 06:49:57 --> Output Class Initialized
INFO - 2016-09-28 06:49:57 --> Security Class Initialized
DEBUG - 2016-09-28 06:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:49:57 --> Input Class Initialized
INFO - 2016-09-28 06:49:57 --> Language Class Initialized
ERROR - 2016-09-28 06:49:57 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 53
INFO - 2016-09-28 06:49:58 --> Config Class Initialized
INFO - 2016-09-28 06:49:58 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:49:58 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:49:58 --> Utf8 Class Initialized
INFO - 2016-09-28 06:49:58 --> URI Class Initialized
INFO - 2016-09-28 06:49:58 --> Router Class Initialized
INFO - 2016-09-28 06:49:58 --> Output Class Initialized
INFO - 2016-09-28 06:49:58 --> Security Class Initialized
DEBUG - 2016-09-28 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:49:58 --> Input Class Initialized
INFO - 2016-09-28 06:49:58 --> Language Class Initialized
ERROR - 2016-09-28 06:49:58 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 53
INFO - 2016-09-28 06:50:38 --> Config Class Initialized
INFO - 2016-09-28 06:50:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:50:38 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:50:38 --> Utf8 Class Initialized
INFO - 2016-09-28 06:50:38 --> URI Class Initialized
INFO - 2016-09-28 06:50:38 --> Router Class Initialized
INFO - 2016-09-28 06:50:38 --> Output Class Initialized
INFO - 2016-09-28 06:50:38 --> Security Class Initialized
DEBUG - 2016-09-28 06:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:50:38 --> Input Class Initialized
INFO - 2016-09-28 06:50:38 --> Language Class Initialized
INFO - 2016-09-28 06:50:38 --> Loader Class Initialized
INFO - 2016-09-28 06:50:38 --> Helper loaded: url_helper
INFO - 2016-09-28 06:50:38 --> Helper loaded: file_helper
INFO - 2016-09-28 06:50:38 --> Helper loaded: form_helper
INFO - 2016-09-28 06:50:38 --> Database Driver Class Initialized
INFO - 2016-09-28 06:50:38 --> Email Class Initialized
INFO - 2016-09-28 06:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:50:38 --> Controller Class Initialized
ERROR - 2016-09-28 06:50:38 --> Severity: Warning --> file_get_contents(http://sibilhussain.com/facebook-api/index.php/Loginservice/login): failed to open stream: HTTP request failed! HTTP/1.1 406 Not Acceptable
 /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 24
INFO - 2016-09-28 06:50:38 --> Final output sent to browser
DEBUG - 2016-09-28 06:50:38 --> Total execution time: 0.0460
INFO - 2016-09-28 06:52:35 --> Config Class Initialized
INFO - 2016-09-28 06:52:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:52:35 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:52:35 --> Utf8 Class Initialized
INFO - 2016-09-28 06:52:35 --> URI Class Initialized
INFO - 2016-09-28 06:52:35 --> Router Class Initialized
INFO - 2016-09-28 06:52:35 --> Output Class Initialized
INFO - 2016-09-28 06:52:35 --> Security Class Initialized
DEBUG - 2016-09-28 06:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:52:35 --> Input Class Initialized
INFO - 2016-09-28 06:52:35 --> Language Class Initialized
INFO - 2016-09-28 06:52:35 --> Loader Class Initialized
INFO - 2016-09-28 06:52:35 --> Helper loaded: url_helper
INFO - 2016-09-28 06:52:35 --> Helper loaded: file_helper
INFO - 2016-09-28 06:52:35 --> Helper loaded: form_helper
INFO - 2016-09-28 06:52:35 --> Database Driver Class Initialized
INFO - 2016-09-28 06:52:35 --> Email Class Initialized
INFO - 2016-09-28 06:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:52:35 --> Controller Class Initialized
ERROR - 2016-09-28 06:52:35 --> Severity: Warning --> file_get_contents(http://sibilhussain.com/facebook-api/index.php/Loginservice/login): failed to open stream: HTTP request failed! HTTP/1.1 406 Not Acceptable
 /home/filebirb/public_html/sibilhussain/facebook-clone/application/controllers/Logincontroller.php 24
INFO - 2016-09-28 06:52:35 --> Final output sent to browser
DEBUG - 2016-09-28 06:52:35 --> Total execution time: 0.0461
INFO - 2016-09-28 06:52:37 --> Config Class Initialized
INFO - 2016-09-28 06:52:37 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:52:37 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:52:37 --> Utf8 Class Initialized
INFO - 2016-09-28 06:52:37 --> URI Class Initialized
DEBUG - 2016-09-28 06:52:37 --> No URI present. Default controller set.
INFO - 2016-09-28 06:52:37 --> Router Class Initialized
INFO - 2016-09-28 06:52:37 --> Output Class Initialized
INFO - 2016-09-28 06:52:37 --> Security Class Initialized
DEBUG - 2016-09-28 06:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:52:37 --> Input Class Initialized
INFO - 2016-09-28 06:52:37 --> Language Class Initialized
INFO - 2016-09-28 06:52:37 --> Loader Class Initialized
INFO - 2016-09-28 06:52:37 --> Helper loaded: url_helper
INFO - 2016-09-28 06:52:37 --> Helper loaded: file_helper
INFO - 2016-09-28 06:52:37 --> Helper loaded: form_helper
INFO - 2016-09-28 06:52:37 --> Database Driver Class Initialized
INFO - 2016-09-28 06:52:37 --> Email Class Initialized
INFO - 2016-09-28 06:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:52:37 --> Controller Class Initialized
INFO - 2016-09-28 06:52:37 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/myview.php
INFO - 2016-09-28 06:52:37 --> Final output sent to browser
DEBUG - 2016-09-28 06:52:37 --> Total execution time: 0.0390
INFO - 2016-09-28 06:52:39 --> Config Class Initialized
INFO - 2016-09-28 06:52:39 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:52:39 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:52:39 --> Utf8 Class Initialized
INFO - 2016-09-28 06:52:39 --> URI Class Initialized
INFO - 2016-09-28 06:52:39 --> Router Class Initialized
INFO - 2016-09-28 06:52:39 --> Output Class Initialized
INFO - 2016-09-28 06:52:39 --> Security Class Initialized
DEBUG - 2016-09-28 06:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:52:39 --> Input Class Initialized
INFO - 2016-09-28 06:52:39 --> Language Class Initialized
INFO - 2016-09-28 06:52:39 --> Loader Class Initialized
INFO - 2016-09-28 06:52:39 --> Helper loaded: url_helper
INFO - 2016-09-28 06:52:39 --> Helper loaded: file_helper
INFO - 2016-09-28 06:52:39 --> Helper loaded: form_helper
INFO - 2016-09-28 06:52:39 --> Database Driver Class Initialized
INFO - 2016-09-28 06:52:39 --> Email Class Initialized
INFO - 2016-09-28 06:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:52:39 --> Controller Class Initialized
INFO - 2016-09-28 06:52:40 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/email_wrg.php
INFO - 2016-09-28 06:52:40 --> Final output sent to browser
DEBUG - 2016-09-28 06:52:40 --> Total execution time: 1.1849
INFO - 2016-09-28 06:53:03 --> Config Class Initialized
INFO - 2016-09-28 06:53:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 06:53:03 --> UTF-8 Support Enabled
INFO - 2016-09-28 06:53:03 --> Utf8 Class Initialized
INFO - 2016-09-28 06:53:03 --> URI Class Initialized
DEBUG - 2016-09-28 06:53:03 --> No URI present. Default controller set.
INFO - 2016-09-28 06:53:03 --> Router Class Initialized
INFO - 2016-09-28 06:53:03 --> Output Class Initialized
INFO - 2016-09-28 06:53:03 --> Security Class Initialized
DEBUG - 2016-09-28 06:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-28 06:53:03 --> Input Class Initialized
INFO - 2016-09-28 06:53:03 --> Language Class Initialized
INFO - 2016-09-28 06:53:03 --> Loader Class Initialized
INFO - 2016-09-28 06:53:03 --> Helper loaded: url_helper
INFO - 2016-09-28 06:53:03 --> Helper loaded: file_helper
INFO - 2016-09-28 06:53:03 --> Helper loaded: form_helper
INFO - 2016-09-28 06:53:03 --> Database Driver Class Initialized
INFO - 2016-09-28 06:53:03 --> Email Class Initialized
INFO - 2016-09-28 06:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-28 06:53:03 --> Controller Class Initialized
INFO - 2016-09-28 06:53:03 --> File loaded: /home/filebirb/public_html/sibilhussain/facebook-clone/application/views/myview.php
INFO - 2016-09-28 06:53:03 --> Final output sent to browser
DEBUG - 2016-09-28 06:53:03 --> Total execution time: 0.0397
