<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logincontroller extends CI_Controller {
//THIS FUNCTION USED TO USER AUTHETICATION
	public function authuser()
	{
		
		$user['email'] = $this->input->get_post('email');
		$user['password'] = $this->input->get_post('password');
		
        
//        WEB SERVICE URL
        
		$url = 'http://sibilhussain.com/facebook-api/index.php/Loginservice/login';
		$options= array(
                 'http'=>array(
                          'header'=>'Content-type: application/x-www-form-urlencoded',
                          'method'=>'POST',
                          'content'=> http_build_query($user),
                 	),
			);
		$content = stream_context_create($options);
		$result= file_get_contents($url,false,$content);
	        $json=json_decode($result,true);
                $user['data']=$json;
        
		
			   if($json['RESPOND']==300)
					  {   
			 	$this->load->view("pass_wrg",$user);
		            	}
		          elseif($json['RESPOND']==400)
			    {
			 	$this->load->view("email_wrg",$user);
                  }
                  elseif ($json['RESPOND']==505) {
                  	$this->load->view("email_wrg",$user);
                  }
                   else
			    {
			    	 
			 	$this->main($user);
                  }
		            	
	}
    
//THIS FUNCTION USED TO SET SESSION DATA AND CHECK THE EMAIL VERIFICATION STATUS
    
	public function main($user)
	{
		        $this->session->set_userdata('ID',$user['data']['ID']);
		        $this->session->set_userdata('Login','true');
		        $this->session->userdata('ID');
		        if($this->session->has_userdata('ID'))
		        {
		        if($user['data']['STATUS'] == 'true')
		        {
		        	$iurl = base_url();
               		 header('Location:'.$iurl.'maincl');    
		        
		        }
		        elseif($user['data']['STATUS'] == 'false')
		        {
		        	$this->load->view("not-verify",$user);
		        }
		        }
		        else
		        {
		    	echo "srry";
		         }  

	}
    
//FUNCTION FOR DESTROY SESSION
    
	public function logout()
	{
		$this->session->sess_destroy();
		header('Location:'.base_url());
	}
	
}
